<?php

namespace mshrm\Events;

abstract class Event
{
    //
}
